<?php
// upload.php – tar emot formuläret från create.php (AJAX med hjälp av fetch)
// Steg: validera -> ladda upp bild -> skapa timereport i API -> spara (report_id, filename) i DB
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/api_client.php';
require_once __DIR__ . '/db.php';

function json_fail(string $msg, int $code = 400, array $extra = []) {
    http_response_code($code);
    echo json_encode(array_merge(['success' => false, 'message' => $msg], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
function json_ok(array $extra = []) {
    echo json_encode(array_merge(['success' => true], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

/* 1) Hämta och validera fält */
$date      = $_POST['date']      ?? '';
$hoursRaw  = $_POST['hours']     ?? '';
$workplace = $_POST['workplace'] ?? '';
$notes     = $_POST['notes']     ?? '';

// Normalisera timmar: tillåt “2,75” -> “2.75” (både komma och punkt fungerar när formulär fylls i)
$hoursNormalized = str_replace(',', '.', trim($hoursRaw));

// Grundkrav
if ($date === '' || $hoursNormalized === '' || $workplace === '') {
    json_fail('Fyll i datum, timmar (t.ex. 2.75) och arbetsplats.', 400, [
        'stage' => 'validate',
        'details' => compact('date','hoursRaw','workplace')
    ]);
}
// Säkerställ att siffror används
if (!is_numeric($hoursNormalized)) {
    json_fail('Timmar måste vara ett tal (ex: 2.5 eller 2,5).', 400, [
        'stage' => 'validate',
        'details' => ['hours_received' => $hoursRaw]
    ]);
}
$hours = (float)$hoursNormalized;

/* 2) Valfri bilduppladdning */
$filename = null; // standard: ingen bild

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        json_fail('Fel vid bilduppladdning (PHP error code: ' . $file['error'] . ').', 400, ['stage' => 'upload']);
    }
    if ($file['size'] > 5 * 1024 * 1024) { 
        json_fail('Filen är för stor. Max 5 MB.', 400, ['stage' => 'upload']); //Storlek max 5mb
    } 

    $allowedExt  = ['jpg','jpeg','png','gif','webp','svg']; //Tillåtna bildformat
    $allowedMime = ['image/jpeg','image/png','image/gif','image/webp','image/svg+xml'];

    $originalName = basename($file['name']);
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($ext, $allowedExt, true) || !in_array($mime, $allowedMime, true)) {
        json_fail('Otillåten filtyp. Tillåtna: ' . implode(', ', $allowedExt) . '.', 400, [
            'stage' => 'upload', 'details' => ['ext' => $ext, 'mime' => $mime]
        ]);
    }

    $targetDir = __DIR__ . '/Uploads';
    if (!is_dir($targetDir)) {
        if (!mkdir($targetDir, 0777, true) && !is_dir($targetDir)) {
            json_fail('Kunde inte skapa Uploads-mapp.', 500, ['stage' => 'upload']);
        }
    }
    if (!is_writable($targetDir)) {
        json_fail('Uploads-mappen är inte skrivbar: ' . $targetDir, 500, ['stage' => 'upload']);
    }

    // Sanera filnamn (ersätt å/ä/ö/mellanslag m.m.)
    $sanitized = preg_replace('/[^A-Za-z0-9\.\-_]/', '_', $originalName);
    $timestamp = date('Ymd_His'); // Prefix med datum och tid före filnamn för att undvika kollidering (dubbletter), exempel: "20251028_213045_filnamn"
    $filename = $timestamp . '-' . $sanitized;
    $targetPath = $targetDir . '/' . $filename;

    // Försök flytta filen
    $moved = @move_uploaded_file($file['tmp_name'], $targetPath);

    // Om move() säger false men filen finns ändå → acceptera och fortsätt
    if (!$moved && !file_exists($targetPath)) {
        error_log("Upload fail: tmp={$file['tmp_name']} target={$targetPath} moved=" . var_export($moved, true));
        json_fail('Kunde inte spara bilduppladdningen.', 500, ['stage' => 'upload']);
    }
}

/* 3) Skapa tidrapport i API:t */
$payload = [
    'date'         => $date,
    'workplace_id' => (int)$workplace,
    'hours'        => $hours,        
    'info'         => (string)$notes,
];

try {
    $created = api_post('/timereport', $payload);
    if (!isset($created['id'])) {
        json_fail('Oväntat svar från API vid skapande av rapport.', 500, [
            'stage' => 'api', 'api_response' => $created
        ]);
    }
    $reportId = (int)$created['id'];
} catch (Throwable $e) {
    // Rensa ev. uppladdad fil om API:t faller
    if ($filename !== null) {
        @unlink(__DIR__ . '/Uploads/' . $filename);
    }
    json_fail('Kunde inte skapa tidrapport i API:t: ' . $e->getMessage(), 500, ['stage' => 'api']);
}

/* 4) Spara (report_id, filename) i DB om bild finns */
if ($filename !== null) {
    try {
        $pdo = db();
        $stmt = $pdo->prepare('INSERT INTO images (report_id, filename) VALUES (?, ?)');
        $stmt->execute([$reportId, $filename]);
    } catch (Throwable $e) {
        // Bilden är redan sparad på disk – ta bort så vi inte lämnar skräp
        @unlink(__DIR__ . '/Uploads/' . $filename);
        json_fail('Kunde inte spara bildinfo i databasen: ' . $e->getMessage(), 500, ['stage' => 'db']);
    }
}

/* 5) Klart */
json_ok([
    'report_id' => $reportId,
    'filename'  => $filename,  // kan vara null om ingen bild
    'stage'     => 'done'
]);
