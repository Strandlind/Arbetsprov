<?php

//Uppgifter för åtkomst till mitt tillfälliga API

define('API_BASE', 'https://arbetsprov.trinax.se/api/v1');
define('API_TOKEN', '79fbf65e4896bfb2434922de8f2cbd32');
