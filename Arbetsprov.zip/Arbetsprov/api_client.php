<?php

require_once __DIR__ . '/config.php';

function api_request(string $method, string $path, array $query = [], array $body = null): array {
    $url = rtrim(API_BASE, '/') . '/' . ltrim($path, '/'); //$url är API_BASE, dvs https://arbetsprov.trinax.se/api/v1

    // Rensa tomma query-parametrar
    $query = array_filter($query, fn($v) => $v !== null && $v !== '');
    if (!empty($query)) {
        $url .= '?' . http_build_query($query);
    }

    //Använder cURL (client URL) i api_client.php varje gång applikationen pratar med Trinax REST-API
    $ch = curl_init($url);

    //HTTP parametrar för autentisering och korrekt format från API
    $headers = [
        'Accept: application/json',
        'Authorization: bearer ' . API_TOKEN, 
    ]; 

    // Basinställningar för hur cURL ska bete sig
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 20,
    ]);

    // Lägger till Json-data om det är POST
    if ($body !== null) {
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE); //Här görs datan om till json före det skickas
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    }

    //Skickar iväg anropet och väntar på svar
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($res === false) {
        throw new RuntimeException('API-fel: ' . $err); //Felmeddelande om anropet saknar svar
    }

    $data = json_decode($res, true);
    if ($code >= 400) {
        $msg = is_array($data) ? json_encode($data, JSON_UNESCAPED_UNICODE) : $res;
        throw new RuntimeException("API {$code}: {$msg}"); //Felmeddelande vid felkoder över 400 (fel från API:t)
    }
    return is_array($data) ? $data : []; // Om svaret innehåller giltig JSON, returneras det som en PHP-array
}

// Hämtar data från befintligt API
function api_get(string $path, array $query = []): array {
    return api_request('GET', $path, $query);
}

// Postar data i befintligt API
function api_post(string $path, array $body): array {
    return api_request('POST', $path, [], $body);
}
