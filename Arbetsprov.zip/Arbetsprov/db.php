<?php
// PDO-anslutning till min lokala MySQL (via XAMPP).

const DB_HOST = '127.0.0.1';  // eller 'localhost'
const DB_NAME = 'arbetsprov_db';
const DB_USER = 'root';
const DB_PASS = '';           

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // kasta exceptions vid fel
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // assoc-array som standard
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }
    return $pdo;
}