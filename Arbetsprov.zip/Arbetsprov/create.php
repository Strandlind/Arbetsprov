<?php

require_once __DIR__ . '/api_client.php';

// Hämta arbetsplatser till dropdown (samma som på index-sidan)
$workplaces = [];
$workplaceError = null;
try {
    $workplaces = api_get('/workplace');
} catch (Throwable $e) {
    $workplaceError = $e->getMessage();
}

// SIDANS UTSEENDE OCH STYLE (Har använt mig av Bootstrap för lite snyggare design)
?>
<!doctype html>
<html lang="sv">
<head>
  <meta charset="utf-8">
  <title>Skapa tidrapport</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap för snygg layout -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  <style>
    body { 
        background:#79cef0; 
        padding:2rem; 
        font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif; 
    }
    .container { 
        background:#fff; 
        border-radius:10px; 
        padding:2rem; 
        max-width:1000px; 
        margin:0 auto; 
        box-shadow:0 0 10px rgba(0,0,0,.08); 
    }
    input, select, textarea, button { 
        background:#fff !important; 
        color:#000 !important; 
    }
    .error { 
        background:#ffe8e8; 
        border-left:4px solid #e23b3b; 
        padding:.75rem; color:#a40000; 
        border-radius:6px; 
    }
    .success { 
        background:#eaffea; 
        border-left:4px solid #2ea043; 
        padding:.75rem; color:#124d12; 
        border-radius:6px; 
    }
    
    /* Sök-knapp fylls när man hovrar */
    .btn-primary:hover {
      background-color: #105f28 !important;
      color: white !important;
    }

    /* Återställ-knapp fylls när man hovrar */
    .btn-outline-secondary:hover {
  background-color: #6c757d !important;  
  color: #fff !important;                
  border-color: #6c757d !important;      
    }
  </style>
</head>

<body>

<div class="container">
  <!-- Enkel navigationsmeny -->
  <nav class="mb-3">
    <div class="d-flex justify-content-center gap-3">
    <a href="index.php"
       class="btn btn-outline-primary px-4 py-2 fw-semibold shadow-sm
       <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active btn-primary text-white' : '' ?>">
       📋 Lista tidrapporter
    </a>

    <a href="create.php"
       class="btn btn-outline-success px-4 py-2 fw-semibold shadow-sm
       <?= basename($_SERVER['PHP_SELF']) === 'create.php' ? 'active btn-success text-white' : '' ?>">
       ➕ Skapa tidrapport
    </a>
  </div>
    <img src="Bilder/logga.png" alt="Företagslogotyp" style="height:60px; width:auto;"> <!-- Lade med en Trinax logga för att göra det lite trevligare -->
  </nav>

  <h1 class="h3 mb-3">Skapa ny tidrapport</h1>
  <p class="text-muted">Fyll i formuläret för att skapa tidrapport. Du kan också fylla i beskrivning och bifoga en bild.</p>

  <!-- Visa fel om arbetsplatser inte kunde hämtas -->
  <?php if ($workplaceError): ?>
    <div class="error mb-3">Kunde inte hämta arbetsplatser: <?= $workplaceError ?></div>
  <?php endif; ?>

  <!-- Meddelanderuta för AJAX-svar -->
  <div id="msg" class="mb-3" style="display:none;"></div>

  <!-- Formuläret: JS skickar det via fetch som Formdata (AJAX) -->
  <form id="reportForm" class="row g-3" enctype="multipart/form-data">
    <!-- Datum -->
    <div class="col-md-4">
      <label for="date" class="form-label">Datum</label>
      <input type="date" class="form-control" id="date" name="date" required>
    </div>

    <!-- Timmar -->
    <div class="col-md-4">
      <label for="hours" class="form-label">Timmar</label>
      <input type="number" class="form-control" id="hours" name="hours" min="0" step="0.25" placeholder="t.ex. 8" required>
    </div>

    <!-- Arbetsplats -->
    <div class="col-md-4">
      <label for="workplace" class="form-label">Arbetsplats</label>
      <select id="workplace" name="workplace" class="form-select" required>
        <option value="">Välj...</option>
        <?php foreach ($workplaces as $w): ?>
          <option value="<?= $w['id'] ?>"><?= $w['name'] ?? ('ID ' . $w['id']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Övrigt -->
    <div class="col-12">
      <label for="notes" class="form-label">Övrigt</label>
      <textarea id="notes" name="notes" class="form-control" rows="3" placeholder="Valfri beskrivning"></textarea>
    </div>

    <!-- Bild -->
    <div class="col-12">
      <label for="image" class="form-label">Bild</label>
      <input type="file" id="image" name="image" class="form-control" accept=".jpg,.jpeg,.png,.gif,.webp,.svg">
      <div class="form-text">Tillåtna format: jpg, jpeg, png, gif, webp, svg. Max 5 MB.</div>
    </div>

    <!-- Knappar -->
    <div class="col-12 d-flex gap-2">
      <button type="submit" class="btn btn-primary">Skapa tidrapport</button>
      <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('reportForm').reset()">Rensa</button>
    </div>
  </form>
</div>

<script>
/**
 * Enkel hjälpare för att visa meddelanden högst upp i formuläret.
 */
function showMessage(type, text) {
  const box = document.getElementById('msg');
  box.className = type === 'success' ? 'success' : 'error';
  box.textContent = text;
  box.style.display = 'block';
}

/** 
AJAX + JS
 
 1. Ingen Form-Post, utan samlar data när man trycker på "Skapa tidrapport"
 2. Hanterar formuläret med AJAX (fetch + FormData).
 3. Skickas till upload.php som gör allt på server-sidan:
  * Laddar upp filen till /Uploads
  * POST:ar timereport till API:et
  * Sparar (report_id, filename) i min lokala databas (MySQL)
  
 */

 document.getElementById('reportForm').addEventListener('submit', async function (e) {
  e.preventDefault(); // Stoppa vanlig form-post

  const form = e.currentTarget;
  const fd = new FormData(form); // plockar upp alla fält + fil

  try {
    const resp = await fetch('upload.php', {
      method: 'POST',
      body: fd // Formdata sätts automatiskt
    });

    // Förvänta JSON-svar från upload.php
    const data = await resp.json();

    if (!resp.ok || data.success !== true) {
      // Om servern skickat error
      showMessage('error', data.message || 'Något gick fel vid skapandet.');
      return;
      }

    // Meddelande om allt lyckades
    showMessage('success', `Tidrapport skapad! ID: ${data.report_id}. Bild: ${data.filename}`);

    // Nollställer formuläret
    form.reset();

  } catch (err) {
    // Nätverksfel, JSON-parse-fel etc.
    showMessage('error', 'Tekniskt fel: ' + (err?.message || err));
  }
});
</script>
</body>
</html>
