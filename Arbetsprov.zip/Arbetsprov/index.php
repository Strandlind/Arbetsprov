<?php
require_once __DIR__ . '/api_client.php'; //Anslutning till api-client.php

// 1. Hämta arbetsplatser för dropdown
$workplaces = []; //Tom array där arbetsplatser lagras
$workplaceError = null; //Variabel för att lagra eventuellt felmeddelande
try {
    $workplaces = api_get('/workplace'); //Try-Catch metod för att försöka anropa API /workplace för att hämta tillgängliga workplaces
} catch (Throwable $e) {
    $workplaceError = $e->getMessage(); //Om API inte svarar, visa felmeddelande
}

// 2. isset för att returnera True eller False beroende på om dessa värden finns i GET-URL:en (anropet). Trim för att ta bort eventuella mellanslag.
$filters = [
    'workplace' => isset($_GET['workplace']) ? trim($_GET['workplace']) : '',
    'from_date' => isset($_GET['from_date']) ? trim($_GET['from_date']) : '',
    'to_date'   => isset($_GET['to_date'])   ? trim($_GET['to_date'])   : '',
];

// 3. Hämta tidrapporter
$timereports = []; //Tom array där tidsrapporter lagras
$timereportError = null; //Variabel för att lagra eventuellt felmeddelande
try {
    // Try-Catch för att se om /timereport matchar med värden i /workplace och /from_date + /to_date
    $timereports = api_get('/timereport', $filters);
} catch (Throwable $e) {
    $timereportError = $e->getMessage(); //Om API inte svarar, visa felmeddelande
}

// 4. Omvandla företagens ID till deras namn i tabellen så det blir enklare att förstå
$workplaceMap = [];
foreach ($workplaces as $w) {
    if (isset($w['id'], $w['name'])) {
        $workplaceMap[(string)$w['id']] = $w['name'];
    }
}

// Sortering av tidrapporter på datum
$sortOrder = isset($_GET['sort']) && strtolower($_GET['sort']) === 'asc' ? 'asc' : 'desc';

usort($timereports, function ($a, $b) use ($sortOrder) {
    // Tolka datum robust (saknas datum -> behandla som 0)
    $ad = isset($a['date']) ? strtotime($a['date']) : 0;
    $bd = isset($b['date']) ? strtotime($b['date']) : 0;

    // Jämför datum
    if ($ad === $bd) {
        // Om samma datum: nyare id först
        return ($sortOrder === 'asc')
            ? (($a['id'] ?? 0) <=> ($b['id'] ?? 0))
            : (($b['id'] ?? 0) <=> ($a['id'] ?? 0));
    }

    // Fallande (desc) betyder nyare datum först
    return ($sortOrder === 'asc') ? ($ad <=> $bd) : ($bd <=> $ad);
});


// SIDANS UTSEENDE OCH STYLE (Har använt mig av Bootstrap för lite snyggare design)
?>
<!doctype html>
<html lang="sv">
<head>
  <meta charset="utf-8">
  <title>Tidrapporter – Lista</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 – används för snyggare knappar, tabeller och layout -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
    crossorigin="anonymous"
  >

  <!-- Egen stil ovanpå Bootstrap -->
  <style>
    body {
      background-color: #79cef0; 
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      padding: 2rem;
    }

    .container {
      background: white;               
      border-radius: 10px;             
      padding: 2rem;
      box-shadow: 0 0 10px rgba(0,0,0,0.1); 
      max-width: 1250px;
      margin: 0 auto;
    }

    /* Vita fält och knappar med svart text */
    input, select, button {
      background-color: white !important;
      color: black !important;
    }

    /* Snyggare sök-knapp med blå kant */
    .btn-custom {
      border: 1px solid #007bff;
      font-weight: 500;
      transition: background-color 0.2s;
    }

    /* Sök-knapp fylls när man hovrar */
    .btn-custom:hover {
      background-color: #007bff !important;
      color: white !important;
    }

    /* Återställ-knapp fylls när man hovrar */
    .btn-outline-secondary:hover {
  background-color: #6c757d !important;  
  color: #fff !important;                
  border-color: #6c757d !important;      
    }

    /* Design för felmeddelanden */
    .error {
      background-color: #ffe8e8;
      border-left: 4px solid #e23b3b;
      padding: 0.75rem;
      color: #a40000;
      margin-bottom: 1rem;
      border-radius: 5px;
    }
  </style>
</head>
<body>

<div class="container">
  <!-- Enkel navigationsmeny -->
  <nav class="mb-3">
    <div class="d-flex justify-content-center gap-3">
    <a href="index.php"
       class="btn btn-outline-primary px-4 py-2 fw-semibold shadow-sm
       <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active btn-primary text-white' : '' ?>">
       📋 Lista tidrapporter
    </a>

    <a href="create.php"
       class="btn btn-outline-success px-4 py-2 fw-semibold shadow-sm
       <?= basename($_SERVER['PHP_SELF']) === 'create.php' ? 'active btn-success text-white' : '' ?>">
       ➕ Skapa tidrapport
    </a>
  </div>
    <img src="Bilder/logga.png" alt="Företagslogotyp" style="height:60px; width:auto;"> <!-- Lade med en Trinax logga för att göra det lite trevligare -->
  </nav>

  <header class="mb-4">
    <h1 class="h3 mb-2">Tidrapporter</h1>
    <p class="text-muted">
      Använd filtren nedan för att söka fram tidrapporter.
      Klicka på <strong>Återställ</strong> för att rensa fälten.
    </p>
  </header>

  <!-- Om API-anropet till arbetsplatser misslyckas -->
  <?php if ($workplaceError): ?>
    <div class="error">
      Kunde inte hämta arbetsplatser: <?= $workplaceError ?>
    </div>
  <?php endif; ?>

  <!-- Formulär för sökning -->
  <form class="row g-3 mb-4" method="get" action="">
    <!-- Arbetsplats -->
    <div class="col-md-4">
      <label for="workplace" class="form-label">Välj arbetsplats</label>
      <select name="workplace" id="workplace" class="form-select">
        <option value="">Alla</option>
        <?php foreach ($workplaces as $w): ?>
          <option value="<?= $w['id'] ?>"
            <?= ($filters['workplace'] !== '' && $filters['workplace'] == (string)$w['id']) ? 'selected' : '' ?>>
            <?= $w['name'] ?? ('ID ' . $w['id']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Från-datum -->
    <div class="col-md-3">
      <label for="from_date" class="form-label">Från-datum</label>
      <input
        type="date"
        name="from_date"
        id="from_date"
        value="<?= $filters['from_date'] ?>"
        class="form-control"
      >
    </div>

    <!-- Till-datum -->
    <div class="col-md-3">
      <label for="to_date" class="form-label">Till-datum</label>
      <input
        type="date"
        name="to_date"
        id="to_date"
        value="<?= $filters['to_date'] ?>"
        class="form-control"
      >
    </div>

    <!-- Knappar -->
    <div class="col-md-2 d-flex align-items-end gap-2">
      <!-- "Sök"-knapp -->
      <button type="submit" class="btn btn-custom w-100">Sök</button>

      <!-- "Återställ"-knapp -->
      <button
        type="button"
        class="btn btn-outline-secondary w-100"
        onclick="window.location.href='index.php'">
        Återställ
      </button>
    </div>
  </form>

  <!-- Om API-anropet till tidrapporter misslyckas -->
  <?php if ($timereportError): ?>
    <div class="error">
      Kunde inte hämta tidrapporter: <?= $timereportError ?>
    </div>
  <?php endif; ?>

  <!-- Tabell med resultat -->
  <div class="table-responsive">
    <table class="table table-striped align-middle">

<?php
  // Länkar som behåller filtren men byter sortering
  $ascUrl  = '?' . http_build_query(array_merge($filters, ['sort' => 'asc']));
  $descUrl = '?' . http_build_query(array_merge($filters, ['sort' => 'desc']));
?>
<thead class="table-light">
  <tr>
    <th>
      Datum
      <a href="<?= $descUrl ?>" title="Nyast först" style="text-decoration:none; margin-left:6px;">↓</a>
      <a href="<?= $ascUrl  ?>" title="Äldst först" style="text-decoration:none; margin-left:4px;">↑</a>
    </th>
    <th>Arbetsplats</th>
    <th>Timmar</th>
  </tr>
</thead>

      <tbody>
        <?php if (empty($timereports)): ?>
          <!-- Meddelande när ingen data hittas -->
          <tr>
            <td colspan="3" class="text-muted text-center">
              Inga poster hittades för vald filtrering.
            </td>
          </tr>
        <?php else: ?>
          <!-- Skriv ut varje rapportrad -->
          <?php foreach ($timereports as $r): ?>
            <tr>
              <td><?= $r['date'] ?? '' ?></td>
              <td>
                <?php
                  $wpId = isset($r['workplace_id']) ? (string)$r['workplace_id'] : '';
                  echo $workplaceMap[$wpId] ?? ('#' . $wpId);
                ?>
              </td>
              <td><?= $r['hours'] ?? '' ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Länk till Bootstrap bibliotek för interaktiv Javascript -->
<script
  src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
  crossorigin="anonymous">
</script>

</body>
</html>